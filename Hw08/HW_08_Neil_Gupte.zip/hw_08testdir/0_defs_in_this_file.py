definitely not function

This is def not a function def 

"""
	This file has:
		- 2 classes
		- 4 functions
		- 25 lines
		- 270 characters
"""

def func1():
    pass

def func2():
    pass

class Foo:
    def __init__(self):
        pass

class Bar:
    def __init__(self):
        pass


if __name__ == "__main__":
    main()

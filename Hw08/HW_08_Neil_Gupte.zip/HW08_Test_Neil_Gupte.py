"""Test File for HW08 with test cases for each function"""

import unittest
from HW08_Neil_Gupte import HW08,FileAnalyzer
from typing import Iterator, Tuple, Dict,List,IO,AnyStr
import os
from datetime import datetime

class DateArithmeticTest(unittest.TestCase):
    """ test date_arithmetic function """
    def test_date_arithmetic(self)->None:
        a:Tuple=HW08().date_arithmetic()
        date1: str = "Mar 1, 2020"
        date2: str = "Mar 2, 2019"
        dt1: datetime = datetime.strptime(date1, '%b %d, %Y')
        dt2: datetime = datetime.strptime(date2, '%b %d, %Y')
        self.assertEqual(a,(dt1,dt2,241))

class FileReaderTest(unittest.TestCase):
    """ test file_reader function """
    def test_file_reader(self)->None:
        strings:List=[['CWID','Name','Major'],['123','Jin He','Computer Science'],
                      ['234','Nanda Koka','Software Engineering'],['345','Benji Cai','Software Engineering']]
        strings1: List = [['123', 'Jin He', 'Computer Science'],
                         ['234', 'Nanda Koka', 'Software Engineering'], ['345', 'Benji Cai', 'Software Engineering']]
        self.assertEqual(list(HW08().file_reader('check.txt',3)),strings)
        self.assertEqual(list(HW08().file_reader('check.txt', 3,',',True)), strings1)
        with self.assertRaises(FileNotFoundError):
            list(HW08().file_reader('abc.txt', 2))
        with self.assertRaises(ValueError):
            list(HW08().file_reader('check.txt', 2))

class FileAnalyzerTest(unittest.TestCase):
    """ test file_analyzer class  functions """
    def test_file_analyze(self)->None:
        a:FileAnalyzer=FileAnalyzer('hw_08testdir')
        file_dict:Dict={'0_defs_in_this_file.py': {'class': 0, 'function': 0, 'line': 3, 'char': 57},
                        'file1.py': {'class': 2, 'function': 4, 'line': 25, 'char': 270}}
        self.assertEqual(a.files_summary,file_dict)
        self.assertRaises(OSError,FileAnalyzer,'abc')
        # self.assertRaises(PermissionError, FileAnalyzer, 'read_prot_test')
        # make a read protected file and check

if __name__=='__main__':
    unittest.main(exit=False,verbosity=2)

"""HW08 practice of datetime arithmetic and files parsing and directory parsing in python"""

from typing import Iterator, Tuple, Dict,List,IO,AnyStr
from datetime import datetime, timedelta
import os
from prettytable import PrettyTable

class HW08:
    """class for functions within the assignment"""
    def date_arithmetic(self) -> Tuple[datetime, datetime, int]:
        """ function to return tuple for answers of date arithmetic """
        date1:str="Feb 27, 2020"
        date2: str = "Feb 27, 2019"
        date3: str = "Feb 1, 2019"
        date4: str = "Sep 30, 2019"

        dt1: datetime = datetime.strptime(date1, '%b %d, %Y')
        dt2: datetime = datetime.strptime(date2, '%b %d, %Y')
        dt3: datetime = datetime.strptime(date3, '%b %d, %Y')
        dt4: datetime = datetime.strptime(date4, '%b %d, %Y')
        diff: datetime = dt4-dt3
        no_days:int=3

        three_days_after_02272020: datetime =dt1+timedelta(days=no_days)
        three_days_after_02272019: datetime = dt2+timedelta(days=no_days)
        days_passed_02012019_09302019: int = diff.days


        return three_days_after_02272020, three_days_after_02272019, days_passed_02012019_09302019


    def file_reader(self,path: str, fields: int,sep:str=',',header:bool=False) -> Iterator[List[str]]:
        """function to parse the file and return the strings inside separated by the given separator symbol"""
        try:
            f:IO[AnyStr]= open(path, 'r')
        except FileNotFoundError:
            raise FileNotFoundError(f"File Not Found at path {path}")
        else:
            count:int = 0
            for line in f:
                count += 1
                split_line = tuple(line.strip('\n').split(sep))
                if len(split_line)!=fields:
                    raise ValueError(f"{path} has {len(split_line)} fields on line {count} but expected {fields}")
                if header==True:
                    header = False
                    continue
                else:
                    yield list(split_line)



class FileAnalyzer:
    """ Class with methods to analyze files."""
    def __init__(self, directory: str) -> None:
        """ Initializer which initializes the dictionary to save info and directory name"""
        self.directory: str = directory
        self.files_summary: Dict[str, Dict[str, int]] = dict()
        self.analyze_files() # summerize the python files data

    def analyze_files(self) -> None:
        """ this method allows checks the path and fills the file_summary dictionary"""
        check:bool=os.path.exists(self.directory)
        if check==False:
            raise OSError("Please check the directory path given")
        file_list:List=os.listdir(self.directory)
        pyfile_list=[item for item in file_list if item.endswith('.py')]
        for file in pyfile_list:
            try:
                f:IO[AnyStr] = open(os.path.join(self.directory, file), 'r')
            except (PermissionError):
                raise PermissionError('The given file cannot be opened for reading')
            except (FileNotFoundError):
                raise FileNotFoundError('The given file is not available at the location')
            else:
                class_no:int=0
                function_no:int=0
                line_no:int=0
                char_no:int=0
                for line in f:
                    char_no += len(line)
                    line_no += 1

                    if line.strip().startswith('def '):
                        function_no += 1
                    if line.strip().startswith('class '):
                        class_no += 1

                self.files_summary[file]={
                    'class':class_no,
                    'function':function_no,  # number of functions in the file
                    'line': line_no,  # number of lines in the file
                    'char': char_no  # number of characters in the file
                }

    def pretty_print(self) -> None:
        """ Function to print collected file info to a table."""
        table:PrettyTable=PrettyTable()
        table.field_names = ['File Name', 'Classes',
                         'Functions', 'Lines', 'Characters']

        for key, value in self.files_summary.items():
            table.add_row([key, value['class'], value['function'],
                       value['line'], value['char']])

        print(table)

